package com.lab6;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestLab6 {

	@Test
	public void test() {
		//fail("Not yet implemented");
		
		String City="Chicago";
		weatherServlet ls= new weatherServlet();
		Double d=ls.foreign(269.489);
		Double cor=13.0;
		assertEquals(d,cor);
		
		
		
		
	}

}
